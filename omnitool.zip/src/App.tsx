import { useState, useMemo, ChangeEvent } from "react";
import { 
  Search, 
  Type, 
  Sparkles, 
  Code2, 
  Palette, 
  Hash, 
  FileText, 
  Copy, 
  Check, 
  Github, 
  ChevronRight,
  Eraser,
  Wand2,
  Download,
  Youtube,
  Image as ImageIcon
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { cn } from "@/lib/utils";

type ToolCategory = "text" | "ai" | "dev" | "design" | "all";

interface Tool {
  id: string;
  name: string;
  description: string;
  icon: any;
  category: ToolCategory;
}

const TOOLS: Tool[] = [
  { id: "case-converter", name: "Case Converter", description: "Convert text between UPPER, lower, and Title Case", icon: Type, category: "text" },
  { id: "word-counter", name: "Word Counter", description: "Count words, characters, and reading time", icon: FileText, category: "text" },
  { id: "lorem-ipsum", name: "Lorem Ipsum", description: "Generate placeholder text for your designs", icon: Type, category: "text" },
  { id: "json-formatter", name: "JSON Formatter", description: "Prettify and validate JSON data", icon: Code2, category: "dev" },
  { id: "base64", name: "Base64 Encoder", description: "Encode and decode text to Base64 format", icon: Code2, category: "dev" },
  { id: "image-converter", name: "Image Converter", description: "Convert images between PNG, JPEG, and WebP", icon: Palette, category: "design" },
  { id: "yt-thumbnail", name: "YT Thumbnail", description: "Download YouTube thumbnails in HD quality", icon: Youtube, category: "design" },
  { id: "password-gen", name: "Password Gen", description: "Create secure, random passwords", icon: Check, category: "dev" },
  { id: "ai-caption", name: "AI Caption Gen", description: "AI-powered social media caption generator", icon: Sparkles, category: "ai" },
  { id: "ai-hashtags", name: "AI Hashtag Gen", description: "Generate relevant hashtags using AI", icon: Hash, category: "ai" },
];

export default function App() {
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState<ToolCategory>("all");
  const [selectedTool, setSelectedTool] = useState<Tool | null>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const filteredTools = useMemo(() => {
    return TOOLS.filter(tool => {
      const matchesSearch = tool.name.toLowerCase().includes(search.toLowerCase()) || 
                          tool.description.toLowerCase().includes(search.toLowerCase());
      const matchesCategory = activeCategory === "all" || tool.category === activeCategory;
      return matchesSearch && matchesCategory;
    });
  }, [search, activeCategory]);

  return (
    <div className="flex h-screen w-full bg-slate-50 overflow-hidden font-sans antialiased">
      {/* Mobile Sidebar Overlay */}
      <AnimatePresence>
        {isSidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setIsSidebarOpen(false)}
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 md:hidden"
          />
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-72 bg-white border-r border-slate-200 transform transition-all duration-300 ease-in-out md:relative md:translate-x-0 h-full flex flex-col shadow-2xl md:shadow-none",
        isSidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="p-8 border-b border-slate-100 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => { setSelectedTool(null); setActiveCategory("all"); setIsSidebarOpen(false); }}>
            <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shadow-lg shadow-blue-200 group-hover:scale-105 transition-transform">
              <Sparkles className="text-white w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-xl tracking-tight text-slate-900 font-display block">OmniTool</span>
              <span className="text-[10px] font-bold text-blue-600 uppercase tracking-widest leading-none">Power Utilities</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="md:hidden text-slate-400" onClick={() => setIsSidebarOpen(false)}>
            <ChevronRight className="w-5 h-5 rotate-180" />
          </Button>
        </div>
        
        <nav className="p-6 flex-1 space-y-2 overflow-y-auto">
          {(["all", "text", "ai", "dev", "design"] as ToolCategory[]).map((cat) => (
            <button
              key={cat}
              onClick={() => { setActiveCategory(cat); setSelectedTool(null); setIsSidebarOpen(false); }}
              className={cn(
                "w-full flex items-center px-4 py-3.5 rounded-xl text-sm font-semibold transition-all relative group",
                activeCategory === cat 
                  ? "text-blue-600" 
                  : "text-slate-500 hover:text-slate-900 hover:bg-slate-50"
              )}
            >
              {activeCategory === cat && (
                <motion.div
                  layoutId="active-nav"
                  className="absolute inset-0 bg-blue-50/80 rounded-xl -z-10 border border-blue-100/50"
                  transition={{ type: "spring", bounce: 0.2, duration: 0.6 }}
                />
              )}
              <span className="capitalize relative z-10">{cat} Tools</span>
              {activeCategory === cat && (
                <div className="ml-auto w-1.5 h-1.5 rounded-full bg-blue-600 z-10 animate-pulse" />
              )}
            </button>
          ))}
        </nav>

        <div className="p-6 shrink-0">
          <div className="bg-slate-900 p-5 rounded-2xl border border-slate-800 relative overflow-hidden group">
            <div className="absolute -right-4 -top-4 w-16 h-16 bg-blue-500/20 rounded-full blur-2xl group-hover:bg-blue-500/30 transition-colors" />
            <p className="text-xs font-bold text-white tracking-wide uppercase mb-1">Elite Access</p>
            <p className="text-[11px] text-slate-400 font-medium leading-relaxed mb-4">
              Unlock advanced API nodes and specialized cloud processing.
            </p>
            <Button size="sm" className="w-full bg-blue-600 hover:bg-blue-700 text-[11px] font-bold h-8 rounded-lg shadow-lg shadow-blue-900/20">
              UPGRADE NOW
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 bg-slate-50/50">
        <header className="h-20 px-6 md:px-10 flex items-center justify-between glass border-b border-slate-200/50 shrink-0 z-30 sticky top-0">
          <div className="flex items-center gap-6 flex-1">
            <Button variant="ghost" size="icon" className="md:hidden text-slate-400 hover:bg-slate-100" onClick={() => setIsSidebarOpen(true)}>
              <ChevronRight className="w-5 h-5 rotate-90" />
            </Button>
            <div className="relative w-full max-w-md group">
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-blue-500 transition-colors" />
              <input 
                type="text"
                placeholder="Find a specialized tool..."
                className="w-full bg-slate-100/50 hover:bg-slate-100 border border-transparent focus:border-blue-500/20 focus:bg-white rounded-2xl py-3 pl-12 pr-6 text-sm text-slate-900 placeholder-slate-400 focus:ring-4 focus:ring-blue-500/5 transition-all outline-none md:min-w-[320px]"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <div className="flex items-center gap-3 md:gap-5 ml-6">
            <div className="hidden sm:flex flex-col items-end mr-1">
              <span className="text-xs font-bold text-slate-900 leading-none mb-1">Developer Admin</span>
              <span className="text-[10px] text-green-600 font-bold uppercase tracking-tighter">System Active</span>
            </div>
            <div className="w-10 h-10 bg-gradient-to-tr from-slate-200 to-slate-100 rounded-2xl border-2 border-white shadow-sm flex items-center justify-center font-bold text-slate-400 text-sm ring-1 ring-slate-200/50">
              AD
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto min-h-0 custom-scrollbar scroll-smooth">
          <main className="p-6 md:p-12 max-w-7xl mx-auto">
            {!selectedTool ? (
              <div className="space-y-10">
                <div className="space-y-2">
                  <Badge variant="outline" className="text-blue-600 border-blue-200 bg-blue-50/50 mb-2 font-bold tracking-wider px-3 py-1 rounded-full text-[10px] uppercase">
                    Utility Suite
                  </Badge>
                  <h1 className="text-3xl md:text-4xl font-extrabold tracking-tight text-slate-900 font-display">
                    {activeCategory === "all" ? "Professional Toolkit" : `${activeCategory.charAt(0).toUpperCase() + activeCategory.slice(1)} Node`}
                  </h1>
                  <p className="text-sm md:text-base text-slate-500 max-w-2xl font-medium">Simple, hardware-accelerated utilities designed for peak performance and clean workflows.</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 md:gap-8">
                  <AnimatePresence mode="popLayout">
                    {filteredTools.map((tool, idx) => (
                      <motion.div
                        key={tool.id}
                        layout
                        initial={{ opacity: 0, y: 20 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95 }}
                        transition={{ duration: 0.3, delay: idx * 0.05 }}
                      >
                        <div 
                          className="group premium-card p-7 flex flex-col h-full cursor-pointer relative overflow-hidden"
                          onClick={() => setSelectedTool(tool)}
                        >
                          <div className="absolute -right-10 -bottom-10 w-24 h-24 bg-slate-50 rounded-full group-hover:scale-[3] transition-transform duration-700 -z-10" />
                          
                          <div className="w-14 h-14 rounded-2xl bg-slate-50 flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white group-hover:rotate-6 group-hover:scale-110 transition-all duration-500 shadow-sm border border-slate-100 group-hover:border-blue-500">
                            <tool.icon className="w-7 h-7 text-slate-600 group-hover:text-inherit" />
                          </div>
                          
                          <div className="flex-1 space-y-2">
                            <h3 className="font-bold text-[17px] text-slate-900 group-hover:text-blue-600 transition-colors font-display line-clamp-1">{tool.name}</h3>
                            <p className="text-[13px] text-slate-500 font-medium leading-relaxed line-clamp-2 transition-colors">
                              {tool.description}
                            </p>
                          </div>
                          
                          <div className="mt-8 flex items-center justify-between pt-5 border-t border-slate-100/50">
                            <span className="text-[10px] font-extrabold uppercase tracking-widest text-slate-400 group-hover:text-slate-600 transition-colors">
                              {tool.category}
                            </span>
                            <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center opacity-0 group-hover:opacity-100 group-hover:bg-blue-50 transition-all duration-300">
                              <ChevronRight className="w-4 h-4 text-blue-600" />
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                </div>
              </div>
            ) : (
              <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3 text-xs font-bold text-slate-400 tracking-widest uppercase">
                    <span className="hover:text-blue-600 cursor-pointer transition-colors" onClick={() => setSelectedTool(null)}>Infrastructure</span>
                    <ChevronRight className="w-3 h-3" />
                    <span className="text-slate-900">{selectedTool.name}</span>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => setSelectedTool(null)} className="text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-lg h-8 px-4 font-bold uppercase tracking-tighter">
                    Close Tool
                  </Button>
                </div>
                
                <motion.div
                  initial={{ opacity: 0, y: 40 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ type: "spring", damping: 20, stiffness: 100 }}
                >
                  <div className="premium-card p-1 overflow-hidden">
                    <ToolInterface tool={selectedTool} onBack={() => setSelectedTool(null)} />
                  </div>
                </motion.div>
              </div>
            )}
          </main>
        </div>

        <footer className="h-16 px-8 flex items-center justify-between bg-white border-t border-slate-200/50 text-[10px] md:text-[11px] text-slate-500 shrink-0 font-medium z-30 glass">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span>OmniTool v1.2.0 • Build 8492 • Local Edge Rendering</span>
          </div>
          <div className="flex gap-6 items-center uppercase tracking-widest font-bold">
            <span className="hidden sm:inline text-slate-400">Total Security Guaranteed</span>
            <span className="hover:text-blue-600 cursor-pointer transition-colors">Support Portal</span>
          </div>
        </footer>
      </div>
    </div>
  );
}

function ToolInterface({ tool, onBack }: { tool: Tool; onBack: () => void }) {
  switch (tool.id) {
    case "case-converter": return <TextConverterTool />;
    case "word-counter": return <WordCounterTool />;
    case "lorem-ipsum": return <LoremIpsumTool />;
    case "json-formatter": return <JSONFormatterTool />;
    case "base64": return <Base64Tool />;
    case "image-converter": return <ImageConverterTool />;
    case "yt-thumbnail": return <YoutubeThumbnailTool />;
    case "password-gen": return <PasswordGeneratorTool />;
    case "ai-caption": return <AICaptionTool />;
    case "ai-hashtags": return <AIHashtagTool />;
    case "color-picker": return <ColorTool />;
    default: return <div>Tool not implemented yet.</div>;
  }
}

// --- Tool Implementations ---

function TextConverterTool() {
  const [text, setText] = useState("");
  
  const convert = (type: "upper" | "lower" | "title") => {
    if (type === "upper") setText(text.toUpperCase());
    if (type === "lower") setText(text.toLowerCase());
    if (type === "title") {
      setText(text.split(" ").map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase()).join(" "));
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="space-y-3">
        <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Content Input</label>
        <Textarea 
          placeholder="Paste or type your text for instant node transformation..." 
          className="min-h-[240px] bg-white border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 transition-all text-base leading-relaxed p-6 shadow-inner"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </div>
      <div className="flex flex-wrap gap-3">
        <Button onClick={() => convert("upper")} variant="outline" className="rounded-xl font-bold uppercase tracking-tight h-11 px-6 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-all">Uppercase</Button>
        <Button onClick={() => convert("lower")} variant="outline" className="rounded-xl font-bold uppercase tracking-tight h-11 px-6 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-all">Lowercase</Button>
        <Button onClick={() => convert("title")} variant="outline" className="rounded-xl font-bold uppercase tracking-tight h-11 px-6 hover:bg-blue-50 hover:text-blue-600 hover:border-blue-200 transition-all">Title Case</Button>
        <Button onClick={() => setText("")} variant="ghost" className="rounded-xl h-11 px-6 text-slate-400 hover:text-red-500 hover:bg-red-50 transition-all ml-auto">
          <Eraser className="w-4 h-4 mr-2" /> Clear Buffer
        </Button>
      </div>
    </div>
  );
}

function WordCounterTool() {
  const [text, setText] = useState("");
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;
  const charsNoSpaces = text.replace(/\s+/g, "").length;
  const readingTime = Math.ceil(words / 200);

  return (
    <div className="space-y-8 p-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatBox label="Words" value={words} />
        <StatBox label="Characters" value={chars} />
        <StatBox label="Chars (no spaces)" value={charsNoSpaces} />
        <StatBox label="Reading Time" value={`${readingTime} min`} />
      </div>
      <div className="space-y-3">
        <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Analysis Buffer</label>
        <Textarea 
          placeholder="Start typing to generate real-time hardware-accelerated metrics..." 
          className="min-h-[320px] bg-white border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 transition-all text-base p-6 shadow-inner"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
      </div>
    </div>
  );
}

function StatBox({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="p-5 bg-slate-50 border border-slate-100 rounded-2xl group hover:border-blue-200 transition-colors">
      <div className="text-[10px] text-slate-400 uppercase font-black tracking-widest mb-2 group-hover:text-blue-500 transition-colors">{label}</div>
      <div className="text-2xl font-black tracking-tight text-slate-900 leading-none">{value}</div>
    </div>
  );
}

function LoremIpsumTool() {
  const [paragraphs, setParagraphs] = useState(3);
  const [result, setResult] = useState("");
  const [copied, setCopied] = useState(false);

  const generate = () => {
    const text = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.";
    setResult(Array(paragraphs).fill(text).join("\n\n"));
    setCopied(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 p-6">
      <div className="flex flex-col md:flex-row items-center gap-6 bg-slate-50 p-6 rounded-2xl border border-slate-100">
        <div className="flex-1 space-y-1">
          <p className="text-sm font-bold text-slate-900 leading-none">Generator Parameters</p>
          <p className="text-xs text-slate-500">Define the volume of placeholder text needed for your prototype.</p>
        </div>
        <div className="flex items-center gap-3 w-full md:w-auto">
          <Input 
            type="number" 
            min={1} max={50} 
            value={paragraphs} 
            onChange={(e) => setParagraphs(Number(e.target.value))}
            className="w-24 h-11 rounded-xl font-bold text-center border-slate-200"
          />
          <Button onClick={generate} className="h-11 px-8 rounded-xl bg-blue-600 hover:bg-blue-700 font-bold gap-2 flex-1 md:flex-none">
            <Wand2 className="w-4 h-4" /> GENERATE
          </Button>
        </div>
      </div>
      
      {result && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative group h-full"
        >
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-inner">
            <div className="h-12 border-b border-slate-100 flex items-center justify-between px-6 bg-slate-50/50">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Generated Output Node</span>
              <Button 
                size="sm" variant="ghost" 
                className="h-8 rounded-lg font-bold text-[10px] uppercase tracking-tighter gap-2"
                onClick={copy}
              >
                {copied ? <><Check className="w-3 h-3 text-green-500" /> COPIED</> : <><Copy className="w-3 h-3" /> COPY DATA</>}
              </Button>
            </div>
            <div className="p-8 max-h-[400px] overflow-y-auto text-slate-600 leading-relaxed text-base font-medium custom-scrollbar whitespace-pre-wrap">
              {result}
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
}

function JSONFormatterTool() {
  const [input, setInput] = useState("");
  const [error, setError] = useState("");

  const format = () => {
    try {
      const obj = JSON.parse(input);
      setInput(JSON.stringify(obj, null, 2));
      setError("");
    } catch (e: any) {
      setError(e.message);
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">JSON Structure</label>
          {error && <span className="text-[10px] font-bold text-red-500 uppercase tracking-tight bg-red-50 px-2 py-0.5 rounded border border-red-100">Invalid Schema</span>}
        </div>
        <Textarea 
          placeholder="Paste raw, messy JSON objects here..." 
          className="min-h-[340px] font-mono text-sm leading-relaxed p-6 bg-slate-900 text-blue-400 rounded-2xl border-slate-800 shadow-2xl custom-scrollbar"
          value={input}
          onChange={(e) => { setInput(e.target.value); if(error) setError(""); }}
        />
        {error && <p className="text-xs text-red-400 font-mono italic">Error: {error}</p>}
      </div>
      <div className="flex flex-wrap gap-3">
        <Button onClick={format} className="rounded-xl h-11 px-8 bg-blue-600 hover:bg-blue-700 font-bold uppercase tracking-tight shadow-lg shadow-blue-900/20">Prettify Payload</Button>
        <Button variant="outline" className="rounded-xl h-11 px-6 font-bold uppercase tracking-tight border-slate-200 hover:bg-slate-50 transition-all" onClick={() => {
          try { setInput(JSON.stringify(JSON.parse(input))); setError(""); } catch (e: any) { setError(e.message); }
        }}>Minify Output</Button>
        <Button variant="ghost" className="rounded-xl h-11 px-6 text-slate-400 hover:text-red-500 hover:bg-red-50 ml-auto transition-all" onClick={() => { setInput(""); setError(""); }}>
          Clear Cache
        </Button>
      </div>
    </div>
  );
}

function Base64Tool() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");

  const encode = () => setOutput(btoa(input));
  const decode = () => {
    try {
      setOutput(atob(input));
    } catch (e) {
      setOutput("Invalid Base64 string");
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-3">
          <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Raw Data Stream</label>
          <Textarea 
            placeholder="Input data to be processed..." 
            className="min-h-[280px] bg-white border-slate-200 rounded-2xl focus:ring-4 focus:ring-blue-500/5 transition-all text-sm p-4 font-mono shadow-inner"
            value={input}
            onChange={(e) => setInput(e.target.value)}
          />
        </div>
        <div className="space-y-3">
          <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Processed Output</label>
          <div className="h-[280px] p-6 bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl relative group">
            <ScrollArea className="h-full w-full break-all font-mono text-sm text-blue-400 custom-scrollbar">
              {output || <span className="text-slate-600 italic">No output generated yet...</span>}
            </ScrollArea>
            {output && (
              <Button 
                size="sm" variant="ghost" 
                className="absolute top-3 right-3 text-slate-400 hover:text-white"
                onClick={() => navigator.clipboard.writeText(output)}
              >
                <Copy className="w-3 h-3" />
              </Button>
            )}
          </div>
        </div>
      </div>
      <div className="flex flex-wrap gap-3">
        <Button onClick={encode} className="rounded-xl h-11 px-8 bg-blue-600 hover:bg-blue-700 font-bold uppercase tracking-tight shadow-lg shadow-blue-900/20">Encode Payload</Button>
        <Button onClick={decode} variant="outline" className="rounded-xl h-11 px-8 border-slate-200 hover:bg-slate-50 font-bold uppercase tracking-tight transition-all">Decode Payload</Button>
        <Button variant="ghost" className="rounded-xl h-11 px-6 text-slate-400 hover:text-red-500 hover:bg-red-50 ml-auto transition-all" onClick={() => { setInput(""); setOutput(""); }}>
          Reset Interface
        </Button>
      </div>
    </div>
  );
}

function AICaptionTool() {
  const [topic, setTopic] = useState("");
  const [tone, setTone] = useState("creative");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const res = await fetch("/api/tools/generate-caption", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic, tone }),
      });
      const data = await res.json();
      setResult(data.result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 p-6">
      <div className="flex flex-col md:flex-row gap-8">
        <div className="flex-1 space-y-6">
          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Content Context</label>
            <Input 
              placeholder="e.g. A serene mountain landscape during winter..." 
              className="h-14 rounded-2xl border-slate-200 bg-white focus:ring-4 focus:ring-blue-500/5 transition-all text-base px-6 shadow-sm"
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
            />
          </div>
          <div className="space-y-3">
            <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Emotional Tone</label>
            <div className="flex flex-wrap gap-2">
              {["Professional", "Funny", "Creative", "Minimal", "Exciting"].map(t => (
                <button 
                  key={t} 
                  onClick={() => setTone(t.toLowerCase())}
                  className={cn(
                    "px-5 py-2 rounded-xl text-xs font-bold transition-all border",
                    tone === t.toLowerCase() 
                      ? "bg-slate-900 text-white border-slate-900 shadow-lg" 
                      : "bg-white text-slate-500 border-slate-100 hover:border-slate-200"
                  )}
                >
                  {t}
                </button>
              ))}
            </div>
          </div>
          <Button onClick={generate} disabled={loading || !topic} className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 font-bold text-lg gap-3 shadow-xl shadow-blue-900/20 transition-all">
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Sparkles className="w-5 h-5 text-yellow-400 fill-yellow-400" />}
            {loading ? "Generating Output..." : "Synthesize Caption"}
          </Button>
        </div>

        {result && (
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="flex-1"
          >
            <div className="h-full bg-slate-50 border border-slate-200 rounded-2xl p-8 relative group overflow-hidden">
              <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/5 rounded-full -mr-12 -mt-12 blur-2xl" />
              <div className="space-y-4 relative z-10">
                <div className="flex items-center gap-2 text-blue-600">
                  <Sparkles className="w-4 h-4" />
                  <span className="text-[10px] font-black uppercase tracking-widest">AI Generated Insight</span>
                </div>
                <p className="text-slate-700 text-lg leading-relaxed font-medium whitespace-pre-wrap">{result}</p>
              </div>
              <Button 
                size="icon" variant="ghost" 
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-900"
                onClick={() => navigator.clipboard.writeText(result)}
              >
                <Copy className="w-4 h-4" />
              </Button>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}

function AIHashtagTool() {
  const [topic, setTopic] = useState("");
  const [result, setResult] = useState("");
  const [loading, setLoading] = useState(false);

  const generate = async () => {
    if (!topic) return;
    setLoading(true);
    try {
      const res = await fetch("/api/tools/generate-hashtags", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ topic }),
      });
      const data = await res.json();
      setResult(data.result);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 p-6">
      <div className="space-y-3">
        <label className="text-sm font-bold text-slate-700 uppercase tracking-tighter">Topic Vector</label>
        <div className="flex gap-3">
          <Input 
            placeholder="e.g. Urban Street Photography 2024..." 
            className="h-14 rounded-2xl border-slate-200 bg-white focus:ring-4 focus:ring-blue-500/5 transition-all text-base px-6 shadow-sm flex-1"
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
          />
          <Button onClick={generate} disabled={loading || !topic} className="h-14 px-10 rounded-2xl bg-blue-600 hover:bg-blue-700 font-bold group shadow-xl shadow-blue-900/20 transition-all">
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Hash className="w-5 h-5 group-hover:rotate-12 transition-transform" />}
          </Button>
        </div>
      </div>
      
      {result && (
        <motion.div 
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          className="bg-slate-50 border border-slate-100 rounded-2xl p-8 relative overflow-hidden"
        >
          <div className="flex items-center gap-2 mb-6">
            <div className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
            <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Trending Cluster Identified</span>
          </div>
          <div className="flex flex-wrap gap-2.5">
            {result.split(" ").map((tag, i) => (
              <Badge key={i} variant="secondary" className="bg-white border-slate-200 text-slate-700 text-sm px-4 py-2 rounded-xl cursor-pointer hover:bg-blue-600 hover:text-white hover:border-blue-500 transition-all shadow-sm">
                {tag}
              </Badge>
            ))}
          </div>
          <Button 
            variant="ghost" 
            size="sm" 
            className="mt-8 text-xs font-bold text-slate-400 hover:text-blue-600 uppercase tracking-tighter h-8 px-4 rounded-lg"
            onClick={() => navigator.clipboard.writeText(result)}
          >
            <Copy className="w-3 h-3 mr-2" /> Data Copy
          </Button>
        </motion.div>
      )}
    </div>
  );
}

function ImageConverterTool() {
  const [file, setFile] = useState<File | null>(null);
  const [format, setFormat] = useState("image/png");
  const [preview, setPreview] = useState<string>("");
  const [converting, setConverting] = useState(false);

  const onFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    if (f) {
      setFile(f);
      setPreview(URL.createObjectURL(f));
    }
  };

  const convert = () => {
    if (!file) return;
    setConverting(true);
    const img = new Image();
    img.src = preview;
    img.onload = () => {
      const canvas = document.createElement("canvas");
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext("2d");
      ctx?.drawImage(img, 0, 0);
      const dataUrl = canvas.toDataURL(format);
      const link = document.createElement("a");
      link.download = `converted-image.${format.split("/")[1]}`;
      link.href = dataUrl;
      link.click();
      setConverting(false);
    };
  };

  return (
    <div className="space-y-8 p-6">
      <div 
        className="group border-2 border-dashed border-slate-200 rounded-[2rem] p-16 text-center hover:border-blue-500/50 hover:bg-blue-50/20 transition-all cursor-pointer relative overflow-hidden active:scale-[0.98]"
        onClick={() => document.getElementById("file-upload")?.click()}
      >
        <input id="file-upload" type="file" className="hidden" accept="image/*" onChange={onFileChange} />
        <div className="absolute inset-0 bg-gradient-to-tr from-white to-slate-50/50 -z-10" />
        {preview ? (
          <div className="relative inline-block group">
            <img src={preview} alt="Preview" className="max-h-72 mx-auto rounded-2xl shadow-xl border-4 border-white" />
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/20 rounded-2xl backdrop-blur-[2px]">
              <span className="text-white text-xs font-black uppercase tracking-widest bg-black/40 px-4 py-2 rounded-full">Change Asset</span>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="w-20 h-20 bg-white shadow-lg rounded-[1.5rem] flex items-center justify-center mx-auto border border-slate-100 group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
              <Palette className="w-8 h-8 text-blue-600" />
            </div>
            <div className="space-y-1">
              <p className="text-lg font-extrabold text-slate-900 tracking-tight leading-none mb-2">Ingest Visual Asset</p>
              <p className="text-sm text-slate-400 font-medium">Click or drag & drop high-density images</p>
              <p className="text-[10px] text-slate-300 font-black uppercase tracking-[0.2em] mt-4">Buffer Support: JPG, PNG, WEBP</p>
            </div>
          </div>
        )}
      </div>

      <AnimatePresence>
        {file && (
          <motion.div 
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 10 }}
            className="flex flex-col md:flex-row items-center gap-6 p-6 bg-slate-50 border border-slate-100 rounded-2xl"
          >
            <div className="flex-1 flex flex-col min-w-0">
              <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1 leading-none">Buffer Data</span>
              <span className="text-sm font-bold text-slate-900 truncate w-full">{file.name}</span>
            </div>
            <div className="flex items-center gap-4 w-full md:w-auto">
              <div className="flex items-center gap-2 bg-white px-3 py-2 rounded-xl border border-slate-200 shadow-sm">
                <span className="text-[10px] text-slate-400 font-black uppercase tracking-tighter">Target Format</span>
                <select 
                  className="bg-transparent border-none p-0 text-xs font-bold font-mono outline-none cursor-pointer"
                  value={format}
                  onChange={(e) => setFormat(e.target.value)}
                >
                  <option value="image/png">PNG</option>
                  <option value="image/jpeg">JPG</option>
                  <option value="image/webp">WEBP</option>
                </select>
              </div>
              <Button onClick={convert} disabled={converting} className="h-12 px-8 rounded-xl bg-blue-600 hover:bg-blue-700 font-bold gap-3 shadow-lg shadow-blue-900/20 active:scale-95 transition-all flex-1 md:flex-none">
                {converting ? <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : <Download className="w-4 h-4" />}
                {converting ? "Processing..." : "Export Node"}
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function YoutubeThumbnailTool() {
  const [url, setUrl] = useState("");
  const [thumbnail, setThumbnail] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const extractThumbnail = () => {
    setLoading(true);
    const videoIdMatch = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([a-zA-Z0-9_-]{11})/);
    setTimeout(() => {
      if (videoIdMatch && videoIdMatch[1]) {
        setThumbnail(`https://img.youtube.com/vi/${videoIdMatch[1]}/maxresdefault.jpg`);
      } else {
        alert("Invalid URL Format");
      }
      setLoading(false);
    }, 600);
  };

  const download = async () => {
    if (!thumbnail) return;
    try {
      const response = await fetch(thumbnail);
      const blob = await response.blob();
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "yt-hq-thumbnail.jpg";
      link.click();
    } catch (e) {
      window.open(thumbnail, "_blank");
    }
  };

  return (
    <div className="space-y-8 p-6">
      <div className="space-y-4">
        <div className="flex items-center gap-2 mb-2">
          <Youtube className="w-5 h-5 text-red-600" />
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Metadata Extraction Node</span>
        </div>
        <div className="flex gap-3">
          <Input 
            placeholder="https://www.youtube.com/watch?v=dQw4w9WgXcQ" 
            className="h-14 rounded-2xl border-slate-200 bg-white focus:ring-4 focus:ring-blue-500/5 transition-all text-base px-6 shadow-sm flex-1"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
          <Button onClick={extractThumbnail} disabled={loading || !url} className="h-14 px-10 rounded-2xl bg-blue-600 hover:bg-blue-700 font-bold group shadow-xl shadow-blue-900/20 active:scale-95 transition-all">
            {loading ? <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" /> : "SCRAPE ASSET"}
          </Button>
        </div>
      </div>

      <AnimatePresence>
        {thumbnail && (
          <motion.div 
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <div className="bg-white p-3 rounded-[1.5rem] border border-slate-200 shadow-2xl relative overflow-hidden group">
              <img src={thumbnail} alt="Thumbnail" className="w-full rounded-2xl transition-transform duration-700 group-hover:scale-105" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent pointer-events-none" />
            </div>
            <Button onClick={download} className="w-full h-14 rounded-2xl bg-slate-900 hover:bg-black font-black text-white gap-3 shadow-xl shadow-slate-900/10 active:scale-95 transition-all">
              <Download className="w-5 h-5" /> EXPORT HIGH-DENSITY FRAME
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function PasswordGeneratorTool() {
  const [length, setLength] = useState(24);
  const [password, setPassword] = useState("");
  const [copied, setCopied] = useState(false);

  const generate = () => {
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+={}[];:/?,.<>";
    let retVal = "";
    for (let i = 0, n = charset.length; i < length; ++i) {
      retVal += charset.charAt(Math.floor(Math.random() * n));
    }
    setPassword(retVal);
    setCopied(false);
  };

  const copy = () => {
    navigator.clipboard.writeText(password);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-8 p-6">
      <div className="p-8 bg-slate-900 rounded-[2.5rem] relative group overflow-hidden shadow-2xl border-4 border-slate-100">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-indigo-500 to-purple-500" />
        <div className="text-slate-500 text-[10px] font-black font-mono uppercase tracking-[0.3em] mb-4">Entropy Encrypted Buffer</div>
        <div className="text-white font-mono text-xl md:text-2xl break-all min-h-[3em] selection:bg-blue-500/30">
          {password || <span className="opacity-10 tracking-[0.2em]">••••••••••••••••••••••••</span>}
        </div>
        {password && (
          <div className="mt-8 flex items-center justify-between">
            <div className="flex gap-2">
              <Badge className="bg-slate-800 text-[10px] font-mono border-slate-700">AES-256</Badge>
              <Badge className="bg-slate-800 text-[10px] font-mono border-slate-700">64-BIT</Badge>
            </div>
            <Button 
              size="sm"
              className={cn(
                "rounded-xl font-bold transition-all px-6 gap-2",
                copied ? "bg-green-600 hover:bg-green-700" : "bg-white text-slate-900 hover:bg-slate-100"
              )}
              onClick={copy}
            >
              {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              {copied ? "COPIED" : "COPY PASSCODE"}
            </Button>
          </div>
        )}
      </div>

      <div className="space-y-8 p-6 bg-slate-50 rounded-3xl border border-slate-100">
        <div className="space-y-4">
          <div className="flex items-center justify-between px-2">
            <div>
              <p className="text-sm font-black text-slate-900 tracking-tight">Complexity Vector</p>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Adjust bit-length for higher entropy</p>
            </div>
            <span className="text-xl font-black font-mono text-blue-600 bg-blue-50 px-4 py-2 rounded-2xl">{length}</span>
          </div>
          <input 
            type="range" min="12" max="128" 
            value={length} 
            onChange={(e) => setLength(Number(e.target.value))}
            className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
          />
        </div>
        <Button onClick={generate} className="w-full h-14 rounded-2xl bg-blue-600 hover:bg-blue-700 font-black text-lg gap-3 shadow-xl shadow-blue-900/20 active:scale-95 transition-all">
          <Sparkles className="w-5 h-5 text-blue-200" /> GENERATE SECURE TOKEN
        </Button>
      </div>
    </div>
  );
}

function ColorTool() {
  const [color, setColor] = useState("#3B82F6");
  
  const hexToRgb = (hex: string) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgb(${r}, ${g}, ${b})`;
  };

  const copy = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="space-y-8 p-6">
      <div className="flex flex-col md:flex-row items-center gap-10">
        <div className="relative group">
          <div className="absolute inset-0 bg-white rounded-[2.5rem] p-1 shadow-2xl border border-slate-100" />
          <input 
            type="color" 
            className="w-48 h-48 rounded-[2.2rem] cursor-crosshair border-none p-0 outline-none relative z-10 transition-transform group-hover:scale-[1.02]"
            value={color}
            onChange={(e) => setColor(e.target.value)}
          />
          <div className="absolute -bottom-4 -right-4 w-12 h-12 bg-white rounded-2xl flex items-center justify-center shadow-lg border border-slate-100 z-20">
            <Palette className="w-5 h-5 text-slate-400" />
          </div>
        </div>
        
        <div className="flex-1 space-y-6 w-full">
          {[
            { label: "HEX Color Node", value: color.toUpperCase() },
            { label: "RGB Vector Buffer", value: hexToRgb(color) }
          ].map((field) => (
            <div key={field.label} className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">{field.label}</label>
              <div className="flex items-center gap-2 group">
                <Input 
                  value={field.value} 
                  readOnly 
                  className="font-mono bg-white border-slate-200 rounded-xl h-12 text-sm font-bold shadow-sm focus:ring-0" 
                />
                <Button 
                  size="icon" 
                  variant="outline" 
                  className="w-12 h-12 rounded-xl border-slate-100 hover:bg-blue-50 group-hover:border-blue-200 transition-all"
                  onClick={() => copy(field.value)}
                >
                  <Copy className="w-4 h-4 text-slate-400" />
                </Button>
              </div>
            </div>
          ))}
          <div className="p-4 bg-slate-50 border border-slate-100 rounded-2xl flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg" style={{ backgroundColor: color }} />
            <p className="text-[10px] font-bold text-slate-500 uppercase tracking-tighter">Live feedback node synchronization active</p>
          </div>
        </div>
      </div>
    </div>
  );
}
